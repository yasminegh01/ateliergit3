#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "background.h"

int main(int argc, char const *argv[])
{
//-----------partie declaration-------//
    int continuer=1;
    background b;
    int direction=0,vitesse=0;
    SDL_Surface *screen;
    SDL_Event event;


//----------partie initialisation------//
    SDL_Init(SDL_INIT_VIDEO);
    screen=SDL_SetVideoMode (800,400,32,SDL_HWSURFACE|SDL_DOUBLEBUF);
    if(Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024)==-1) printf("%s",Mix_GetError());
    SDL_WM_SetCaption("background\t1",NULL);
    initBack(&b);
    SDL_EnableKeyRepeat(30,30);

while (continuer) // ------boucle de jeu --------//
{
//------partie input--------//
    while(SDL_PollEvent(&event))
    {
        switch (event.type)
        {
        case SDL_QUIT:
            continuer=0;
            break;
        case SDL_KEYDOWN:    
            vitesse++;
            switch (event.key.keysym.sym)
            {
                case SDLK_RIGHT:
                    direction='R';
                   // vitesse++;
                    break;
                case SDLK_LEFT:
                    direction='L';
                   // vitesse++;
                    break;
                case SDLK_UP:
                    direction='U';
                   // vitesse++;
                    break;
                case SDLK_DOWN:
                    direction='D';
                   // vitesse++;
                    break;            
            }
        break;
        case SDL_KEYUP:
            vitesse=0;
        break;
        }
    }

//------partie update------//
scrolling(&b,direction,vitesse);  



//------partie affichage------//
aficherBack(b,screen);
SDL_Flip(screen);
SDL_Delay(40);
}

    return 0;
}
